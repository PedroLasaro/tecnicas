package Trabalho_bonus_2;

public abstract class Figura {
    Ponto pOrigem;

    public abstract float calcularArea();
}
