package CK235_496640_TRAB_03.Questao_1;

public interface Colorida   {

    // item f
    String desenhar();

    void move(float dx, float dy);

    float calcularArea();
}
