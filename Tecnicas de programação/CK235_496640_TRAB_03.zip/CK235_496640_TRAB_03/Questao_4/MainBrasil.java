package CK235_496640_TRAB_03.Questao_4;

public class MainBrasil {
    public static void main(String[] args) {
        Brasil br1 = new Brasil();
        br1.buscar("AC");
        br1.buscar("CE");
        br1.buscar("PO");
        br1.buscar("BA");
        br1.buscar("RJ");
    }
}
